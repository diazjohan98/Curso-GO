package main

import "proy_final/cmd"

func main() {
	cmd.Execute()
}
