package main

import "bonus/cmd"

func main() {
    cmd.Execute()
}
