package main

import "cap7/cmd"

func main() {
    cmd.Execute()
}
