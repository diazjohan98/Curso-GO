package main

import (
	"fmt"
//	"os"
)


func main() {
    fmt.Println("Hola, Go!")
	saludar("Jorge")
}

