package main

import "fmt"

func saludar(nombre string) {
    fmt.Println("Hola,", nombre)
}